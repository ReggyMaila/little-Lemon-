//
//  Dish+CoreDataClass.swift
//  littleLemonFinalTest
//
//  Created by Axel Sarmiento on 2023-02-13.
//

import Foundation
import CoreData

@objc(Dish)
public class Dish: NSManagedObject {

}
