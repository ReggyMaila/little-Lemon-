//
//  Helpers.swift
//  littleLemonFinalTest
//
//  Created by Axel Sarmiento on 2023-02-06.
//

import SwiftUI

extension Color {
    static let primaryColor = Color("AccentColor")
    static let secondaryColor = Color("Secondary")
    static let highlightColor = Color("highlight")
}

extension Font {
    
    static func headline(size: CGFloat = 26) -> Font {
        return .custom("Markazi Text", size: size)
    }
    
    static func body(size: CGFloat = 16) -> Font {
        return .custom("Karla Regular", size: size)
    }
}
