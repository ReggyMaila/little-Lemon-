//
//  Profile Screen.swift
//  littleLemonFinalTest
//
//  Created by Axel Sarmiento on 2023-02-06.
//

import SwiftUI


//enum UserDetailsFormType {
//    case register
//    case view
//}

struct Profile_Screen: View {
    // let type: UserDetailsFormType
    func loadSavedValues() {
        firstName = savedFirstName
        lastName = savedLastName
        email = savedEmail
        phone = savedPhone
    }
    @AppStorage(AppConstants.KOrderStatusChecked) var orderStatusChecked: Bool = false
    @AppStorage(AppConstants.KPasswordChangesChecked) var passwordChangesChecked: Bool = false
    @AppStorage(AppConstants.KSpecialOffersChecked) var specialOffersChecked: Bool = false
    @AppStorage(AppConstants.KNewsLetterChecked) var newsLetterChecked: Bool = false
    @AppStorage(AppConstants.kIsLoggedIn) var isLoggedIn: Bool = false
    @AppStorage(AppConstants.kFirstName) var savedFirstName: String = ""
    @AppStorage(AppConstants.KLastName) var savedLastName: String = ""
    @AppStorage(AppConstants.KEmail) var savedEmail: String = ""
    @AppStorage(AppConstants.KPhone) var savedPhone: String = ""
    @State private var showErrorAlert = false
    @State private var showSavedSuccessAlert = false
    @State private var firstName = ""
    @State private var lastName = ""
    @State private var email = ""
    @State private var phone = ""
    var body: some View {
        NavigationView {
            ScrollView{
                VStack(alignment: .leading){
                    Text("Personal information")
                        .fontWeight(.bold)
                    
                    VStack(alignment: .leading){
                        Text("Avatar")
                            .foregroundColor(.highlightColor)
                        HStack(alignment: .top){
                            Image("Profile")
                                .resizable()
                                .frame(width: 80, height: 80)
                            
                            Button(action: {
                                print("Change")
                            }, label: {
                                Text("Change")
                                    .foregroundColor(.white)
                                    .font(.body(size: 13))
                                    .fontWeight(.bold)
                            })
                            .padding()
                            .background(Color.primaryColor)
                            .cornerRadius(5)
                            .padding(.top, 12)
                            
                            Button(action: {
                                print("Remove")
                            }, label: {
                                Text("Remove")
                                    .foregroundColor(.gray)
                                    .font(.body(size: 13))
                                    .fontWeight(.bold)
                            })
                            .padding(15)
                            .border(Color.primaryColor, width: 1)
                            .padding(.top, 12)
                        }
                    }
                }
                .padding(.init(top: 0, leading: 0, bottom: 0, trailing: 80))
                
                VStack(alignment: .leading){
                    Text("First Name")
                        .font(.caption2)
                        .fontWeight(.bold)
                        .foregroundColor(.gray)
                    
                    TextField("", text: $firstName)
                        .textFieldStyle(.roundedBorder)
                    
                    Text("Last Name")
                        .font(.caption2)
                        .fontWeight(.bold)
                        .foregroundColor(.gray)
                    
                    TextField("", text: $lastName)
                        .textFieldStyle(.roundedBorder)
                    
                    Text("Email")
                        .font(.caption2)
                        .fontWeight(.bold)
                        .foregroundColor(.gray)
                    
                    TextField("", text: $email)
                        .textFieldStyle(.roundedBorder)
                    
                    Text("Phone Number")
                        .font(.caption2)
                        .fontWeight(.bold)
                        .foregroundColor(.gray)
                    
                    TextField("", text: $phone)
                        .textFieldStyle(.roundedBorder)
                }
                
                VStack(alignment: .leading){
                    Text("Email notifications")
                        .font(Font.body)
                        .fontWeight(.bold)
                    Spacer().frame(height: 10)
                    HStack {
                        Image(systemName: orderStatusChecked ? "checkmark.square.fill" : "square")
                            .foregroundColor(orderStatusChecked ? Color.primaryColor : Color.secondary)
                            .onTapGesture {
                                orderStatusChecked.toggle()
                            }
                        Text("Order Statuses")
                            .font(.body)
                            .foregroundColor(.primaryColor)
                        
                        
                    }
                    Spacer().frame(height: 10)
                    
                    HStack {
                        Image(systemName: passwordChangesChecked ? "checkmark.square.fill" : "square")
                            .foregroundColor(passwordChangesChecked ? Color.primaryColor : Color.secondary)
                            .onTapGesture {
                                passwordChangesChecked.toggle()
                            }
                        Text("Password Changes")
                            .font(.body)
                            .foregroundColor(.primaryColor)
                    }
                    Spacer().frame(height: 10)
                    
                    HStack {
                        Image(systemName: specialOffersChecked ? "checkmark.square.fill" : "square")
                            .foregroundColor(specialOffersChecked ? Color.primaryColor : Color.secondary)
                            .onTapGesture {
                                specialOffersChecked.toggle()
                            }
                        Text("Special offers")
                            .font(.body)
                            .foregroundColor(.primaryColor)
                    }
                    Spacer().frame(height: 10)
                    
                    HStack {
                        Image(systemName: newsLetterChecked ? "checkmark.square.fill" : "square")
                            .foregroundColor(newsLetterChecked ? Color.primaryColor : Color.secondary)
                            .onTapGesture {
                                newsLetterChecked.toggle()
                            }
                        Text("Newsletter")
                            .font(.body)
                            .foregroundColor(.primaryColor)
                        Spacer().frame(height: 10)
                    }
                    
                    
                    
                }
                
                
                
                VStack{
                    
                    Button(action: {
                        isLoggedIn = false
                    }, label: {
                        Text("Log out")
                            .fontWeight(.bold)
                    })
                    .padding()
                    .frame(minWidth: 0, maxWidth: .infinity)
                    .background(Color.secondaryColor)
                    .cornerRadius(10)
                    .padding(.top, 0)
                }
                
                HStack{
                    Button(action: {
                        loadSavedValues()
                    }, label: {
                        Text("Discard changes")
                            .fontWeight(.bold)
                            .font(.caption)
                    })
                    .padding()
                    .frame(minWidth: 0, maxWidth: .infinity)
                    .background(Color.white)
                    .cornerRadius(10)
                    .border(Color.accentColor, width: 1)
                    
                    
                    
                    
                    Button(action: {
                        submit()
                    }, label: {
                        Text("Save changes")
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                            .font(.caption)
                    })
                    .padding()
                    .frame(minWidth: 0, maxWidth: .infinity)
                    .background(Color.accentColor)
                    .cornerRadius(10)
                    
                }
                .padding(EdgeInsets(top: 20, leading: 30, bottom: 0, trailing: 30))
                
                
            }
            .padding()
            .frame(
                maxWidth: .infinity,
                alignment: .leading
            )
            .border(Color.highlightColor, width: 1)
            .cornerRadius(16)
            .padding(8)
            .onAppear(){
                
                   loadSavedValues()
                
            }
            //            .navigationBarTitleDisplayMode(.inline)
            //            .toolbar {
            //                ToolbarItem(placement: .principal) {
            //                    Image("Logo")
            //                        .resizable()
            //                        .scaledToFit()
            //                        .frame(height: 30)
            //                }
            //            }
            //            .navigationBarItems(trailing:Image("Profile")
            //                .resizable()
            //                .scaledToFit()
            //                .frame(width: 50, height: 50))
        }
        
    }
    
    
    private func submit() {
        if (!firstName.isEmpty &&
            !lastName.isEmpty &&
            !email.isEmpty &&
            !phone.isEmpty &&
            isValidEmail(email)) {
            saveData()
            
            //            if type == .view {
                            showSavedSuccessAlert.toggle()
            //            }
            //        } else {
            //            showErrorAlert.toggle()
            //        }
        }
        
        
        func saveData() {
            UserDefaults.standard.set(firstName, forKey: AppConstants.kFirstName)
            UserDefaults.standard.set(lastName, forKey: AppConstants.KLastName)
            UserDefaults.standard.set(email, forKey: AppConstants.KEmail)
            UserDefaults.standard.set(phone, forKey: AppConstants.KPhone)
            isLoggedIn = true
        }
        
       
    }
    
    struct Profile_Screen_Previews: PreviewProvider {
        static var previews: some View {
            Profile_Screen()
        }
    }
    
    
    
    private func isValidEmail(_ email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }
    
    
}
