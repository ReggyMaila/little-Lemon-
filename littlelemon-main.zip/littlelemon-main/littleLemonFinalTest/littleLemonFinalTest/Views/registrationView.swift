//
//  registrationView.swift
//  littleLemonFinalTest
//
//  Created by Axel Sarmiento on 2023-02-13.
//

import SwiftUI

struct registrationScreen: View {
    @AppStorage(AppConstants.kShowOnboarding) var showOnboardingScreen: Bool = true
    @AppStorage(AppConstants.kIsLoggedIn) var isLoggedIn: Bool = false
    
    var body: some View {
        NavigationView {
            VStack {
                NavigationLink(
                    destination: HomeMenu()
                        .navigationBarBackButtonHidden(true),
                    isActive: $isLoggedIn
                ) { EmptyView() }
                
                ScrollView {
                    VStack {
                        Image("Logo")
                            .padding(.vertical, 8)
                        heroView()
                        newuserform(type: .register)
                            .padding()
                    }
                }
            }
        }
        .fullScreenCover(isPresented: $showOnboardingScreen) {
            onBoarding()
           
        }
    }
}

struct RegistrationScreen_Previews: PreviewProvider {
    static var previews: some View {
        registrationScreen()
    }
}
