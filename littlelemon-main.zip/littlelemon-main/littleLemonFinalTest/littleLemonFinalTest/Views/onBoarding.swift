//
//  onBoarding.swift
//  littleLemonFinalTest
//
//  Created by Axel Sarmiento on 2023-02-13.
//

import SwiftUI

struct onBoarding: View {
    @Environment(\.dismiss) var dismiss
    
    @State var activePageTag = 1
    
    let pages = [
        PageViewItem(
            title: "",
            description: "",
            imageName: "Logo"),
        
        PageViewItem(
            title: "See the best food in town!",
            description: "",
            imageName: "chef"),
        
        PageViewItem(
            title: "Sign in and order today!",
            description: "",
            imageName: "littlelemoneating")
    ]
    
    private func nextPage() {
        if(activePageTag < pages.count) {
            activePageTag += 1
        } else {
            setOnboardingPageViewed()
        }
    }
    
    private func setOnboardingPageViewed() {
        UserDefaults.standard.set(false, forKey: "KShowOnboarding")
        dismiss()
    }
    
    var body: some View {
        VStack {
            TabView (selection: $activePageTag) {
                PageDetails(pageViewItem: pages[0])
                    .tag(1)
                PageDetails(pageViewItem: pages[1])
                    .tag(2)
                PageDetails(pageViewItem: pages[2])
                    .tag(3)
            }
            .tabViewStyle(.page)
            .indexViewStyle(.page(backgroundDisplayMode: .always))
                
            Button(action: {
                nextPage()
            }, label: {
                Text(activePageTag == pages.count ? "Sign In" : "Next")
                    .foregroundColor(.black)
                    .font(.body)
                    .fontWeight(.bold)
                    .frame(maxWidth: .infinity)
            })
            .padding()
            .frame(minWidth: 0, maxWidth: .infinity)
            .background(Color.accentColor)
            .cornerRadius(16)
            .padding()
            
        }
    }
}

struct OnboardingScreen_Previews: PreviewProvider {
    static var previews: some View {
        onBoarding()
    }
}
