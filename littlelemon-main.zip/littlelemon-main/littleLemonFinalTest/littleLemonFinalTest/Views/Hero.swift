//
//  Hero.swift
//  littleLemonFinalTest
//
//  Created by Axel Sarmiento on 2023-02-06.
//

import SwiftUI

struct Hero: View {
    let onSearchTextFieldChanged: (_ value: String) -> Void
    
    @State var searchEnabled = false
    @State var searchFieldExpanded = false
    @State var searchText = ""
    
    init( searchEnabled: Bool = false, onSearchTextFieldChanged: @escaping (_: String) -> Void = {_ in }) {
        self.searchEnabled = searchEnabled
        self.onSearchTextFieldChanged = onSearchTextFieldChanged
    }
    
    private func toggleSearchField() {
        withAnimation {
            searchFieldExpanded.toggle()
        }
    }
    
    var body: some View {
        
            VStack {
                VStack(alignment: .leading) {
                    Text("Little Lemon")
                        .font(.title)
                        .foregroundColor(.secondaryColor)

                    HStack (alignment: .center){
                        VStack(alignment: .leading){
                            Text("Chicago")
                                .font(.subheadline)
                                .foregroundColor(.white)
                                .padding(.bottom, 8)
                            
                            Text("We are a family owned Mediterranean restaurant, focused on traditional recipes served with a modern twist.")
                                .font(.body)
                                .foregroundColor(.white)
                        }
                        
                        Image("Hero image")
                            .resizable()
                            .scaledToFill()
                            .frame(width: 132, height: 132)
                            .cornerRadius(16)
                            .padding(.leading, 10)
                    }
                    .padding(.top, -80)
                    
                    if searchEnabled {
                        if searchFieldExpanded {
                            HStack {
                                TextField("Search...", text: $searchText)
                                    .textFieldStyle(.roundedBorder)
                                    .onChange (of: searchText) {
                                        onSearchTextFieldChanged($0)
                                    }
                                Image(systemName: "xmark")
                                    .frame(width: 30, height: 30)
                                    .background(.white)
                                    .clipShape(Circle())
                                    .onTapGesture {
                                        searchText = ""
                                        toggleSearchField()
                                    }
                            }
                        } else {
                            Image(systemName: "magnifyingglass")
                                .frame(width: 34, height: 34)
                                .background(.white)
                                .clipShape(Circle())
                                .onTapGesture {
                                    toggleSearchField()
                                }
                        }
                    }
                }
                .padding()
                .frame(
                  minWidth: 0,
                  maxWidth: .infinity,
                  alignment: .topLeading
                )
                .background(Color.primaryColor)
            }
        }
    }


struct Hero_Previews: PreviewProvider {
    static var previews: some View {
        Hero()
    }
}
