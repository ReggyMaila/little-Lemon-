//
//  HomeMenu.swift
//  littleLemonFinalTest
//
//  Created by Axel Sarmiento on 2023-02-06.
//

import SwiftUI

struct HomeMenu: View {
    var body: some View {
        TabView {
            landingPage()
                .tabItem {
                    Label("Menu", systemImage: "list.dash")
                }
            Profile_Screen()
                .tabItem {
                    Label("Profile", systemImage: "square.and.pencil")
                }
        }
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .principal) {
                Image("Logo")
                    .resizable()
                    .scaledToFit()
                    .frame(height: 30)
            }
        }
        .navigationBarItems(trailing:Image("Profile")
            .resizable()
            .scaledToFit()
            .frame(width: 30, height: 30))
        
            
        
    }

    
}

struct HomeMenu_Previews: PreviewProvider {
    static var previews: some View {
        HomeMenu()
    }
}
