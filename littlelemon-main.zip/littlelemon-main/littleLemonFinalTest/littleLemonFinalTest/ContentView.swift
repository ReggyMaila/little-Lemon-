//
//  ContentView.swift
//  littleLemonFinalTest
//
//  Created by Axel Sarmiento on 2023-02-06.
//

import SwiftUI
import CoreData

struct ContentView: View {
   

    var body: some View {
        NavigationView {
            
         HomeMenu()
        }
    }


    
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

