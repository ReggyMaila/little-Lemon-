//
//  MenuList.swift
//  littleLemonFinalTest
//
//  Created by Axel Sarmiento on 2023-02-06.
//

import Foundation
import CoreData
import SwiftUI

struct MenuList: Decodable {
    let menu: [MenuItem]
}

struct MenuItem: Decodable, Hashable {
    let id: Int
    let title: String
    let image: String
    let price: String
    let description: String
    let category: String
}

struct PageViewItem {
    let title: String
    let description: String
    let imageName: String
}


struct FetchedObjects<T, Content>: View where T : NSManagedObject, Content : View {
    
  let content: ([T]) -> Content

  var request: FetchRequest<T>
  var results: FetchedResults<T>{ request.wrappedValue }
    
  init(
    predicate: NSPredicate = NSPredicate(value: true),
    sortDescriptors: [NSSortDescriptor] = [],
    @ViewBuilder content: @escaping ([T]) -> Content
  ) {
    self.content = content
    self.request = FetchRequest(
      entity: T.entity(),
      sortDescriptors: sortDescriptors,
      predicate: predicate
    )
  }
  
  var body: some View {
    self.content(results.map { $0 })
  }
}
