//
//  littleLemonFinalTestApp.swift
//  littleLemonFinalTest
//
//  Created by Axel Sarmiento on 2023-02-06.
//

import SwiftUI

@main
struct littleLemonFinalTestApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            registrationScreen()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
